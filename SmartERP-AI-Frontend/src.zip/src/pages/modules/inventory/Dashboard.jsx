import React, { useMemo, useState } from "react";
import { createPortal } from "react-dom";

const Dashboard = () => {
  /* =========================================================
     MAIN STATE
  ========================================================= */

  const [activeTab, setActiveTab] = useState("Stock");
  const [activeFilter, setActiveFilter] = useState("All");
  const [search, setSearch] = useState("");

  const [showAddItem, setShowAddItem] = useState(false);
  const [showStockTake, setShowStockTake] = useState(false);
  const [showAddWarehouse, setShowAddWarehouse] = useState(false);
  const [showMovement, setShowMovement] = useState(false);

  const [editingWarehouse, setEditingWarehouse] = useState(null);
  const [selectedWarehouse, setSelectedWarehouse] = useState(null);

  /* =========================================================
     WAREHOUSES
  ========================================================= */

  const [warehouses, setWarehouses] = useState([
    {
      id: 1,
      code: "W1",
      name: "Main Warehouse",
      location: "Pune",
      manager: "Rahul Patil",
      capacity: 5000,
      used: 3200,
      status: "ACTIVE",
    },
    {
      id: 2,
      code: "W2",
      name: "Stores",
      location: "Mumbai",
      manager: "Amit Shah",
      capacity: 3000,
      used: 1800,
      status: "ACTIVE",
    },
    {
      id: 3,
      code: "W3",
      name: "Finished Goods",
      location: "Nashik",
      manager: "Sneha Joshi",
      capacity: 4000,
      used: 2500,
      status: "ACTIVE",
    },
  ]);

  /* =========================================================
     INVENTORY
  ========================================================= */

  const [inventory, setInventory] = useState([
    {
      sku: "SKU-1042",
      name: "Steel Plate 10mm",
      category: "Raw Materials",
      warehouse: "W1 – Main Warehouse",
      quantity: 840,
      minLevel: 200,
      unit: "kg",
      value: "₹4,20,000",
      status: "IN STOCK",
    },
    {
      sku: "SKU-1041",
      name: "Zinc Ingot",
      category: "Raw Materials",
      warehouse: "W1 – Main Warehouse",
      quantity: 120,
      minLevel: 150,
      unit: "kg",
      value: "₹1,80,000",
      status: "LOW STOCK",
    },
    {
      sku: "SKU-1040",
      name: "M8 Hex Bolts (Box/200)",
      category: "Hardware",
      warehouse: "W2 – Stores",
      quantity: 0,
      minLevel: 50,
      unit: "box",
      value: "₹0",
      status: "OUT OF STOCK",
    },
    {
      sku: "SKU-1039",
      name: "Sigma Brackets A4",
      category: "Components",
      warehouse: "W1 – Main Warehouse",
      quantity: 340,
      minLevel: 100,
      unit: "pcs",
      value: "₹2,04,000",
      status: "IN STOCK",
    },
    {
      sku: "SKU-1038",
      name: "Hydraulic Oil 15W40",
      category: "Consumable",
      warehouse: "W2 – Stores",
      quantity: 28,
      minLevel: 40,
      unit: "litre",
      value: "₹11,200",
      status: "LOW STOCK",
    },
    {
      sku: "SKU-1037",
      name: "Safety Gloves (pair)",
      category: "PPE",
      warehouse: "W2 – Stores",
      quantity: 150,
      minLevel: 60,
      unit: "pair",
      value: "₹18,000",
      status: "IN STOCK",
    },
  ]);

  /* =========================================================
     MOVEMENTS
  ========================================================= */

  const [movements, setMovements] = useState([
    {
      id: 1,
      date: "19 Aug 2026",
      sku: "SKU-1042",
      item: "Steel Plate 10mm",
      type: "IN",
      quantity: 200,
      warehouse: "W1 – Main Warehouse",
      reference: "PO-2041",
    },
    {
      id: 2,
      date: "18 Aug 2026",
      sku: "SKU-1040",
      item: "M8 Hex Bolts",
      type: "OUT",
      quantity: 50,
      warehouse: "W2 – Stores",
      reference: "SO-1092",
    },
    {
      id: 3,
      date: "17 Aug 2026",
      sku: "SKU-1039",
      item: "Sigma Brackets A4",
      type: "TRANSFER",
      quantity: 40,
      warehouse: "W1 → W2",
      reference: "TR-0032",
    },
  ]);

  /* =========================================================
     FORMS
  ========================================================= */

  const [itemForm, setItemForm] = useState({
    name: "",
    category: "",
    warehouse: "W1 – Main Warehouse",
    quantity: "",
    minLevel: "",
    unit: "pcs",
    value: "",
  });

  const [warehouseForm, setWarehouseForm] = useState({
    name: "",
    location: "",
    manager: "",
    capacity: "",
    used: "",
  });

  const [movementForm, setMovementForm] = useState({
    sku: "",
    type: "IN",
    quantity: "",
    warehouse: "W1 – Main Warehouse",
    reference: "",
  });

  const tabs = [
    "Stock",
    "Warehouses",
    "Movements",
    "Replenishment",
  ];

  const filters = [
    "All",
    "In Stock",
    "Low Stock",
    "Out of Stock",
  ];

  /* =========================================================
     STATUS
  ========================================================= */

  const getStatus = (quantity, minLevel) => {
    if (Number(quantity) === 0) return "OUT OF STOCK";

    if (Number(quantity) < Number(minLevel)) {
      return "LOW STOCK";
    }

    return "IN STOCK";
  };

  const getStatusClass = (status) => {
    if (status === "IN STOCK") {
      return "bg-[#e3ecdf] text-[#40563d]";
    }

    if (status === "LOW STOCK") {
      return "bg-[#eeeadd] text-[#776c4d]";
    }

    return "bg-[#eadfdd] text-[#785c58]";
  };

  /* =========================================================
     STOCK FILTER
  ========================================================= */

  const filteredInventory = useMemo(() => {
    return inventory.filter((item) => {
      const searchValue = search.toLowerCase().trim();

      const matchesSearch =
        item.name.toLowerCase().includes(searchValue) ||
        item.sku.toLowerCase().includes(searchValue);

      const matchesFilter =
        activeFilter === "All" ||
        (activeFilter === "In Stock" &&
          item.status === "IN STOCK") ||
        (activeFilter === "Low Stock" &&
          item.status === "LOW STOCK") ||
        (activeFilter === "Out of Stock" &&
          item.status === "OUT OF STOCK");

      return matchesSearch && matchesFilter;
    });
  }, [inventory, search, activeFilter]);

  /* =========================================================
     WAREHOUSE CLICK
     
     THIS IS THE IMPORTANT PART
  ========================================================= */

  const handleWarehouseClick = (warehouse) => {
    console.log("Warehouse clicked:", warehouse);

    setSelectedWarehouse(warehouse);
  };

  const closeWarehouseDetails = () => {
    setSelectedWarehouse(null);
  };

  /* =========================================================
     ADD ITEM
  ========================================================= */

  const handleAddItem = (e) => {
    e.preventDefault();

    const quantity = Number(itemForm.quantity);
    const minLevel = Number(itemForm.minLevel);

    const newItem = {
      sku: `SKU-${1043 + inventory.length}`,
      name: itemForm.name,
      category: itemForm.category,
      warehouse: itemForm.warehouse,
      quantity,
      minLevel,
      unit: itemForm.unit,
      value: itemForm.value
        ? `₹${Number(itemForm.value).toLocaleString("en-IN")}`
        : "₹0",
      status: getStatus(quantity, minLevel),
    };

    setInventory((prev) => [...prev, newItem]);

    setItemForm({
      name: "",
      category: "",
      warehouse: "W1 – Main Warehouse",
      quantity: "",
      minLevel: "",
      unit: "pcs",
      value: "",
    });

    setShowAddItem(false);
  };

  /* =========================================================
     ADD / EDIT WAREHOUSE
  ========================================================= */

  const resetWarehouseForm = () => {
    setWarehouseForm({
      name: "",
      location: "",
      manager: "",
      capacity: "",
      used: "",
    });
  };

  const openAddWarehouse = () => {
    setEditingWarehouse(null);
    resetWarehouseForm();
    setShowAddWarehouse(true);
  };

  const handleWarehouseSubmit = (e) => {
    e.preventDefault();

    const capacity = Number(warehouseForm.capacity);
    const used = Number(warehouseForm.used);

    if (capacity <= 0) {
      alert("Capacity must be greater than 0.");
      return;
    }

    if (used < 0) {
      alert("Used capacity cannot be negative.");
      return;
    }

    if (used > capacity) {
      alert("Used capacity cannot be greater than total capacity.");
      return;
    }

    let savedWarehouse;

    if (editingWarehouse) {
      savedWarehouse = {
        ...editingWarehouse,
        name: warehouseForm.name,
        location: warehouseForm.location,
        manager: warehouseForm.manager,
        capacity,
        used,
      };

      setWarehouses((prev) =>
        prev.map((warehouse) =>
          warehouse.id === editingWarehouse.id
            ? savedWarehouse
            : warehouse
        )
      );

      /*
        If the user is currently viewing this warehouse,
        update the details modal immediately.
      */
      if (
        selectedWarehouse &&
        selectedWarehouse.id === editingWarehouse.id
      ) {
        setSelectedWarehouse(savedWarehouse);
      }
    } else {
      savedWarehouse = {
        id: Date.now(),
        code: `W${warehouses.length + 1}`,
        name: warehouseForm.name,
        location: warehouseForm.location,
        manager: warehouseForm.manager,
        capacity,
        used,
        status: "ACTIVE",
      };

      setWarehouses((prev) => [...prev, savedWarehouse]);
    }

    resetWarehouseForm();
    setEditingWarehouse(null);
    setShowAddWarehouse(false);
  };

  const handleEditWarehouse = (warehouse) => {
    setEditingWarehouse(warehouse);

    setWarehouseForm({
      name: warehouse.name,
      location: warehouse.location,
      manager: warehouse.manager,
      capacity: warehouse.capacity,
      used: warehouse.used,
    });

    setShowAddWarehouse(true);
  };

  const handleDeleteWarehouse = (id) => {
    const warehouse = warehouses.find(
      (item) => item.id === id
    );

    if (!warehouse) return;

    const confirmed = window.confirm(
      `Delete ${warehouse.name}?`
    );

    if (!confirmed) return;

    setWarehouses((prev) =>
      prev.filter((item) => item.id !== id)
    );

    if (
      selectedWarehouse &&
      selectedWarehouse.id === id
    ) {
      setSelectedWarehouse(null);
    }
  };

  /* =========================================================
     MOVEMENT
  ========================================================= */

  const handleMovement = (e) => {
    e.preventDefault();

    const qty = Number(movementForm.quantity);

    if (!movementForm.sku || qty <= 0) {
      alert("Please select an item and enter a valid quantity.");
      return;
    }

    const selectedItem = inventory.find(
      (item) => item.sku === movementForm.sku
    );

    if (!selectedItem) {
      alert("Item not found.");
      return;
    }

    setInventory((prev) =>
      prev.map((item) => {
        if (item.sku !== movementForm.sku) {
          return item;
        }

        let newQuantity = item.quantity;

        if (movementForm.type === "IN") {
          newQuantity += qty;
        }

        if (movementForm.type === "OUT") {
          newQuantity = Math.max(
            0,
            newQuantity - qty
          );
        }

        return {
          ...item,
          quantity: newQuantity,
          status: getStatus(
            newQuantity,
            item.minLevel
          ),
        };
      })
    );

    setMovements((prev) => [
      {
        id: Date.now(),
        date: "19 Aug 2026",
        sku: selectedItem.sku,
        item: selectedItem.name,
        type: movementForm.type,
        quantity: qty,
        warehouse: movementForm.warehouse,
        reference: movementForm.reference || "-",
      },
      ...prev,
    ]);

    setMovementForm({
      sku: "",
      type: "IN",
      quantity: "",
      warehouse: "W1 – Main Warehouse",
      reference: "",
    });

    setShowMovement(false);
  };

  /* =========================================================
     REPLENISHMENT
  ========================================================= */

  const replenishmentItems = inventory.filter(
    (item) =>
      item.status === "LOW STOCK" ||
      item.status === "OUT OF STOCK"
  );

  const handleReorder = (item) => {
    alert(
      `Reorder request created for ${item.name} (${item.sku})`
    );
  };

  /* =========================================================
     STOCK TAKE
  ========================================================= */

  const handleStockTake = () => {
    alert("Stock take started successfully.");
    setShowStockTake(false);
  };

  /* =========================================================
     STATS
  ========================================================= */

  const totalSKUs = inventory.length;

  const lowStock = inventory.filter(
    (item) => item.status === "LOW STOCK"
  ).length;

  const outOfStock = inventory.filter(
    (item) => item.status === "OUT OF STOCK"
  ).length;

  /* =========================================================
     RENDER
  ========================================================= */

  return (
    <div className="min-h-screen bg-[#f5f3ee] p-6">

      {/* =====================================================
          HEADER
      ===================================================== */}

      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-7">

        <div>
          <p className="text-[10px] tracking-[0.25em] text-gray-500 uppercase mb-2">
            Inventory
          </p>

          <h1 className="text-3xl font-serif text-gray-900">
            Inventory Control
          </h1>
        </div>

        <div className="flex gap-2 mt-4 md:mt-0">

          <button
            type="button"
            onClick={() => setShowStockTake(true)}
            className="px-5 py-3 rounded-xl border border-gray-200 bg-white text-xs font-medium hover:bg-gray-50"
          >
            Stock Take
          </button>

          <button
            type="button"
            onClick={() => setShowAddItem(true)}
            className="px-5 py-3 rounded-xl bg-gray-900 text-white text-xs font-medium hover:bg-gray-800"
          >
            + Add Item
          </button>

        </div>
      </div>

      {/* =====================================================
          STATISTICS
      ===================================================== */}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-5">

        <div className="bg-white border border-[#e4e1da] rounded-2xl px-5 py-4">
          <h2 className="text-2xl font-serif text-gray-900">
            {totalSKUs}
          </h2>

          <p className="text-[9px] tracking-[0.18em] text-gray-400 mt-2">
            TOTAL SKUS
          </p>

          <p className="text-[10px] text-gray-500 mt-1">
            Across {warehouses.length} warehouses
          </p>
        </div>

        <div className="bg-white border border-[#e4e1da] rounded-2xl px-5 py-4">
          <h2 className="text-2xl font-serif text-gray-900">
            ₹2.44 Cr
          </h2>

          <p className="text-[9px] tracking-[0.18em] text-gray-400 mt-2">
            STOCK VALUE
          </p>

          <p className="text-[10px] text-gray-500 mt-1">
            At cost price
          </p>
        </div>

        <div className="bg-white border border-[#e4e1da] rounded-2xl px-5 py-4">
          <h2 className="text-2xl font-serif text-gray-900">
            {lowStock}
          </h2>

          <p className="text-[9px] tracking-[0.18em] text-gray-400 mt-2">
            LOW STOCK ITEMS
          </p>

          <p className="text-[10px] text-gray-500 mt-1">
            Need reorder
          </p>
        </div>

        <div className="bg-white border border-[#e4e1da] rounded-2xl px-5 py-4">
          <h2 className="text-2xl font-serif text-gray-900">
            {outOfStock}
          </h2>

          <p className="text-[9px] tracking-[0.18em] text-gray-400 mt-2">
            OUT OF STOCK
          </p>

          <p className="text-[10px] text-gray-500 mt-1">
            Urgent action needed
          </p>
        </div>

      </div>

      {/* =====================================================
          TABS
      ===================================================== */}

      <div className="flex gap-2 mb-5 overflow-x-auto">

        {tabs.map((tab) => (
          <button
            type="button"
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-5 py-2.5 rounded-lg text-[10px] tracking-[0.15em] uppercase whitespace-nowrap transition ${
              activeTab === tab
                ? "bg-white shadow-sm text-gray-900"
                : "text-gray-400 hover:text-gray-700"
            }`}
          >
            {tab}
          </button>
        ))}

      </div>

      {/* =====================================================
          STOCK
      ===================================================== */}

      {activeTab === "Stock" && (
        <div className="bg-white border border-[#e4e1da] rounded-2xl overflow-hidden">

          <div className="p-4 border-b border-[#e8e5df] flex flex-col lg:flex-row gap-3 justify-between">

            <div className="relative w-full lg:w-80">

              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                ⌕
              </span>

              <input
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                type="text"
                placeholder="Search by name or SKU..."
                className="w-full bg-[#f7f6f2] border border-gray-200 rounded-xl py-2.5 pl-10 pr-4 text-xs outline-none focus:border-gray-400"
              />

            </div>

            <div className="flex gap-2 overflow-x-auto">

              {filters.map((filter) => (
                <button
                  type="button"
                  key={filter}
                  onClick={() =>
                    setActiveFilter(filter)
                  }
                  className={`px-3 py-2 rounded-lg border text-[10px] whitespace-nowrap ${
                    activeFilter === filter
                      ? "bg-gray-900 text-white border-gray-900"
                      : "bg-white text-gray-500 border-gray-200"
                  }`}
                >
                  {filter}
                </button>
              ))}

            </div>

          </div>

          <div className="overflow-x-auto">

            <table className="w-full min-w-[950px] text-left">

              <thead>
                <tr className="bg-[#faf9f6] border-b border-[#e8e5df]">

                  {[
                    "SKU",
                    "ITEM NAME",
                    "CATEGORY",
                    "WAREHOUSE",
                    "QTY",
                    "MIN LEVEL",
                    "UNIT",
                    "VALUE",
                    "STATUS",
                  ].map((heading) => (
                    <th
                      key={heading}
                      className="px-4 py-3 text-[9px] tracking-widest text-gray-400 font-medium"
                    >
                      {heading}
                    </th>
                  ))}

                </tr>
              </thead>

              <tbody>

                {filteredInventory.map((item) => (
                  <tr
                    key={item.sku}
                    className="border-b border-[#eeeae3] last:border-b-0 hover:bg-[#faf9f6]"
                  >

                    <td className="px-4 py-4 text-[10px] text-gray-400">
                      {item.sku}
                    </td>

                    <td className="px-4 py-4">
                      <p className="text-sm font-serif text-gray-900 max-w-[130px]">
                        {item.name}
                      </p>
                    </td>

                    <td className="px-4 py-4">
                      <span className="px-2 py-1 rounded-md border border-gray-200 text-[9px] text-gray-500">
                        {item.category}
                      </span>
                    </td>

                    <td className="px-4 py-4">
                      <button
                        type="button"
                        onClick={() => {
                          const warehouse = warehouses.find(
                            (w) =>
                              item.warehouse.startsWith(
                                w.code
                              )
                          );

                          if (warehouse) {
                            handleWarehouseClick(
                              warehouse
                            );
                          }
                        }}
                        className="text-[10px] text-gray-500 hover:text-gray-900 hover:underline text-left"
                      >
                        {item.warehouse}
                      </button>
                    </td>

                    <td
                      className={`px-4 py-4 text-sm ${
                        item.quantity === 0
                          ? "text-red-700"
                          : "text-gray-900"
                      }`}
                    >
                      {item.quantity}
                    </td>

                    <td className="px-4 py-4 text-[10px] text-gray-400">
                      {item.minLevel}
                    </td>

                    <td className="px-4 py-4 text-[10px] text-gray-500">
                      {item.unit}
                    </td>

                    <td className="px-4 py-4 text-xs text-gray-900">
                      {item.value}
                    </td>

                    <td className="px-4 py-4">

                      <span
                        className={`inline-block px-3 py-2 rounded-lg text-[9px] tracking-widest ${getStatusClass(
                          item.status
                        )}`}
                      >
                        {item.status}
                      </span>

                    </td>

                  </tr>
                ))}

              </tbody>

            </table>

          </div>

        </div>
      )}

      {/* =====================================================
          WAREHOUSES
      ===================================================== */}

      {activeTab === "Warehouses" && (
        <div className="bg-white border border-[#e4e1da] rounded-2xl overflow-hidden">

          <div className="p-5 flex items-center justify-between border-b border-[#e8e5df]">

            <div>
              <h2 className="text-lg font-serif text-gray-900">
                Warehouses
              </h2>

              <p className="text-xs text-gray-500 mt-1">
                Manage all your storage locations
              </p>
            </div>

            <button
              type="button"
              onClick={openAddWarehouse}
              className="px-4 py-2.5 rounded-lg bg-gray-900 text-white text-xs hover:bg-gray-800"
            >
              + Add Warehouse
            </button>

          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-5">

            {warehouses.map((warehouse) => {

              const percentage =
                warehouse.capacity > 0
                  ? Math.round(
                      (warehouse.used /
                        warehouse.capacity) *
                        100
                    )
                  : 0;

              const warehouseItems =
                inventory.filter((item) =>
                  item.warehouse.startsWith(
                    warehouse.code
                  )
                ).length;

              return (
                <div
                  key={warehouse.id}
                  className="border border-[#e4e1da] rounded-2xl p-5 hover:shadow-md hover:border-gray-300 transition"
                >

                  {/* CLICKABLE AREA */}
                  <div
                    role="button"
                    tabIndex={0}
                    onClick={() =>
                      handleWarehouseClick(warehouse)
                    }
                    onKeyDown={(e) => {
                      if (
                        e.key === "Enter" ||
                        e.key === " "
                      ) {
                        e.preventDefault();
                        handleWarehouseClick(
                          warehouse
                        );
                      }
                    }}
                    className="cursor-pointer outline-none"
                  >

                    <div className="flex justify-between items-start">

                      <div>
                        <p className="text-[10px] text-gray-400 tracking-widest">
                          {warehouse.code}
                        </p>

                        <h3 className="text-lg font-serif text-gray-900 mt-1">
                          {warehouse.name}
                        </h3>
                      </div>

                      <span className="px-2 py-1 rounded-md bg-[#e3ecdf] text-[#40563d] text-[9px]">
                        {warehouse.status}
                      </span>

                    </div>

                    <div className="mt-5 space-y-3">

                      <div className="flex justify-between text-xs">
                        <span className="text-gray-400">
                          Location
                        </span>

                        <span className="text-gray-700">
                          {warehouse.location}
                        </span>
                      </div>

                      <div className="flex justify-between text-xs">
                        <span className="text-gray-400">
                          Manager
                        </span>

                        <span className="text-gray-700">
                          {warehouse.manager}
                        </span>
                      </div>

                      <div className="flex justify-between text-xs">
                        <span className="text-gray-400">
                          Items
                        </span>

                        <span className="text-gray-700">
                          {warehouseItems}
                        </span>
                      </div>

                      <div>

                        <div className="flex justify-between text-xs mb-2">

                          <span className="text-gray-400">
                            Capacity
                          </span>

                          <span className="text-gray-700">
                            {warehouse.used.toLocaleString()}{" "}
                            /{" "}
                            {warehouse.capacity.toLocaleString()}
                          </span>

                        </div>

                        <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">

                          <div
                            className={`h-full ${
                              percentage >= 90
                                ? "bg-red-500"
                                : percentage >= 70
                                ? "bg-yellow-500"
                                : "bg-gray-800"
                            }`}
                            style={{
                              width: `${Math.min(
                                percentage,
                                100
                              )}%`,
                            }}
                          />

                        </div>

                        <p className="text-[10px] text-gray-400 mt-1">
                          {percentage}% utilized
                        </p>

                      </div>

                    </div>

                    {/* CLEAR CLICK BUTTON */}
                    <div className="mt-4">
                      <span className="inline-flex items-center gap-1 text-[10px] text-gray-500">
                        Click to view details
                        <span>→</span>
                      </span>
                    </div>

                  </div>

                  {/* ACTION BUTTONS */}
                  <div className="flex gap-2 mt-5 pt-4 border-t border-gray-100">

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEditWarehouse(
                          warehouse
                        );
                      }}
                      className="flex-1 py-2 rounded-lg border border-gray-200 text-xs hover:bg-gray-50"
                    >
                      Edit
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteWarehouse(
                          warehouse.id
                        );
                      }}
                      className="flex-1 py-2 rounded-lg border border-red-100 text-red-600 text-xs hover:bg-red-50"
                    >
                      Delete
                    </button>

                  </div>

                </div>
              );
            })}

          </div>

        </div>
      )}

      {/* =====================================================
          MOVEMENTS
      ===================================================== */}

      {activeTab === "Movements" && (
        <div className="bg-white border border-[#e4e1da] rounded-2xl overflow-hidden">

          <div className="p-5 flex justify-between items-center border-b border-[#e8e5df]">

            <div>
              <h2 className="text-lg font-serif text-gray-900">
                Stock Movements
              </h2>

              <p className="text-xs text-gray-500 mt-1">
                Track stock coming in, going out and transfers
              </p>
            </div>

            <button
              type="button"
              onClick={() => setShowMovement(true)}
              className="px-4 py-2.5 rounded-lg bg-gray-900 text-white text-xs"
            >
              + Add Movement
            </button>

          </div>

          <div className="overflow-x-auto">

            <table className="w-full min-w-[800px] text-left">

              <thead>
                <tr className="bg-[#faf9f6] border-b border-[#e8e5df]">

                  {[
                    "DATE",
                    "SKU",
                    "ITEM",
                    "TYPE",
                    "QUANTITY",
                    "WAREHOUSE",
                    "REFERENCE",
                  ].map((heading) => (
                    <th
                      key={heading}
                      className="px-5 py-3 text-[9px] tracking-widest text-gray-400"
                    >
                      {heading}
                    </th>
                  ))}

                </tr>
              </thead>

              <tbody>

                {movements.map((movement) => (
                  <tr
                    key={movement.id}
                    className="border-b border-[#eeeae3]"
                  >

                    <td className="px-5 py-4 text-xs text-gray-500">
                      {movement.date}
                    </td>

                    <td className="px-5 py-4 text-xs text-gray-400">
                      {movement.sku}
                    </td>

                    <td className="px-5 py-4 text-sm font-serif">
                      {movement.item}
                    </td>

                    <td className="px-5 py-4">

                      <span
                        className={`px-3 py-1.5 rounded-lg text-[9px] ${
                          movement.type === "IN"
                            ? "bg-[#e3ecdf] text-[#40563d]"
                            : movement.type === "OUT"
                            ? "bg-[#eadfdd] text-[#785c58]"
                            : "bg-[#eeeadd] text-[#776c4d]"
                        }`}
                      >
                        {movement.type}
                      </span>

                    </td>

                    <td className="px-5 py-4 text-sm">
                      {movement.quantity}
                    </td>

                    <td className="px-5 py-4 text-xs text-gray-500">
                      {movement.warehouse}
                    </td>

                    <td className="px-5 py-4 text-xs text-gray-500">
                      {movement.reference}
                    </td>

                  </tr>
                ))}

              </tbody>

            </table>

          </div>

        </div>
      )}

      {/* =====================================================
          REPLENISHMENT
      ===================================================== */}

      {activeTab === "Replenishment" && (
        <div className="bg-white border border-[#e4e1da] rounded-2xl overflow-hidden">

          <div className="p-5 border-b border-[#e8e5df]">

            <h2 className="text-lg font-serif text-gray-900">
              Replenishment
            </h2>

            <p className="text-xs text-gray-500 mt-1">
              Items that require immediate restocking
            </p>

          </div>

          {replenishmentItems.length === 0 ? (

            <div className="p-10 text-center">

              <p className="text-lg font-serif text-gray-900">
                All stock levels are healthy
              </p>

              <p className="text-xs text-gray-500 mt-2">
                No items currently require replenishment.
              </p>

            </div>

          ) : (

            <div className="divide-y divide-[#eeeae3]">

              {replenishmentItems.map((item) => (

                <div
                  key={item.sku}
                  className="p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4"
                >

                  <div>

                    <div className="flex items-center gap-3">

                      <h3 className="text-sm font-serif text-gray-900">
                        {item.name}
                      </h3>

                      <span
                        className={`px-2 py-1 rounded-md text-[9px] ${getStatusClass(
                          item.status
                        )}`}
                      >
                        {item.status}
                      </span>

                    </div>

                    <p className="text-[10px] text-gray-400 mt-2">
                      {item.sku} • {item.warehouse}
                    </p>

                    <p className="text-xs text-gray-500 mt-1">
                      Current:{" "}
                      <strong>{item.quantity}</strong>{" "}
                      {item.unit} &nbsp; | &nbsp; Minimum:{" "}
                      <strong>{item.minLevel}</strong>
                    </p>

                  </div>

                  <button
                    type="button"
                    onClick={() => handleReorder(item)}
                    className="px-5 py-2.5 rounded-lg bg-gray-900 text-white text-xs"
                  >
                    Create Reorder
                  </button>

                </div>

              ))}

            </div>

          )}

        </div>
      )}

      {/* =====================================================
          ADD ITEM MODAL
      ===================================================== */}

      {showAddItem && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">

          <form
            onSubmit={handleAddItem}
            className="bg-white rounded-2xl w-full max-w-lg p-6 shadow-2xl"
          >

            <div className="flex justify-between items-center mb-5">

              <h2 className="text-xl font-serif">
                Add Inventory Item
              </h2>

              <button
                type="button"
                onClick={() => setShowAddItem(false)}
                className="text-gray-400 text-xl"
              >
                ×
              </button>

            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

              <input
                required
                placeholder="Item name"
                value={itemForm.name}
                onChange={(e) =>
                  setItemForm({
                    ...itemForm,
                    name: e.target.value,
                  })
                }
                className="input"
              />

              <input
                required
                placeholder="Category"
                value={itemForm.category}
                onChange={(e) =>
                  setItemForm({
                    ...itemForm,
                    category: e.target.value,
                  })
                }
                className="input"
              />

              <select
                value={itemForm.warehouse}
                onChange={(e) =>
                  setItemForm({
                    ...itemForm,
                    warehouse: e.target.value,
                  })
                }
                className="input"
              >
                {warehouses.map((warehouse) => (
                  <option
                    key={warehouse.id}
                    value={`${warehouse.code} – ${warehouse.name}`}
                  >
                    {warehouse.code} – {warehouse.name}
                  </option>
                ))}
              </select>

              <input
                required
                type="number"
                min="0"
                placeholder="Quantity"
                value={itemForm.quantity}
                onChange={(e) =>
                  setItemForm({
                    ...itemForm,
                    quantity: e.target.value,
                  })
                }
                className="input"
              />

              <input
                required
                type="number"
                min="0"
                placeholder="Minimum level"
                value={itemForm.minLevel}
                onChange={(e) =>
                  setItemForm({
                    ...itemForm,
                    minLevel: e.target.value,
                  })
                }
                className="input"
              />

              <select
                value={itemForm.unit}
                onChange={(e) =>
                  setItemForm({
                    ...itemForm,
                    unit: e.target.value,
                  })
                }
                className="input"
              >
                <option>pcs</option>
                <option>kg</option>
                <option>box</option>
                <option>litre</option>
                <option>pair</option>
              </select>

              <input
                type="number"
                min="0"
                placeholder="Stock value"
                value={itemForm.value}
                onChange={(e) =>
                  setItemForm({
                    ...itemForm,
                    value: e.target.value,
                  })
                }
                className="input md:col-span-2"
              />

            </div>

            <div className="flex justify-end gap-2 mt-6">

              <button
                type="button"
                onClick={() => setShowAddItem(false)}
                className="px-5 py-2.5 rounded-lg border border-gray-200 text-xs"
              >
                Cancel
              </button>

              <button
                type="submit"
                className="px-5 py-2.5 rounded-lg bg-gray-900 text-white text-xs"
              >
                Add Item
              </button>

            </div>

          </form>

        </div>
      )}

      {/* =====================================================
          ADD / EDIT WAREHOUSE MODAL
      ===================================================== */}

      {showAddWarehouse && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">

          <form
            onSubmit={handleWarehouseSubmit}
            className="bg-white rounded-2xl w-full max-w-lg p-6 shadow-2xl"
          >

            <div className="flex justify-between items-center mb-5">

              <h2 className="text-xl font-serif">
                {editingWarehouse
                  ? "Edit Warehouse"
                  : "Add Warehouse"}
              </h2>

              <button
                type="button"
                onClick={() =>
                  setShowAddWarehouse(false)
                }
                className="text-gray-400 text-xl"
              >
                ×
              </button>

            </div>

            <div className="space-y-4">

              <input
                required
                placeholder="Warehouse name"
                value={warehouseForm.name}
                onChange={(e) =>
                  setWarehouseForm({
                    ...warehouseForm,
                    name: e.target.value,
                  })
                }
                className="input"
              />

              <input
                required
                placeholder="Location"
                value={warehouseForm.location}
                onChange={(e) =>
                  setWarehouseForm({
                    ...warehouseForm,
                    location: e.target.value,
                  })
                }
                className="input"
              />

              <input
                required
                placeholder="Manager"
                value={warehouseForm.manager}
                onChange={(e) =>
                  setWarehouseForm({
                    ...warehouseForm,
                    manager: e.target.value,
                  })
                }
                className="input"
              />

              <div className="grid grid-cols-2 gap-4">

                <input
                  required
                  type="number"
                  min="1"
                  placeholder="Total capacity"
                  value={warehouseForm.capacity}
                  onChange={(e) =>
                    setWarehouseForm({
                      ...warehouseForm,
                      capacity: e.target.value,
                    })
                  }
                  className="input"
                />

                <input
                  required
                  type="number"
                  min="0"
                  placeholder="Used capacity"
                  value={warehouseForm.used}
                  onChange={(e) =>
                    setWarehouseForm({
                      ...warehouseForm,
                      used: e.target.value,
                    })
                  }
                  className="input"
                />

              </div>

            </div>

            <div className="flex justify-end gap-2 mt-6">

              <button
                type="button"
                onClick={() =>
                  setShowAddWarehouse(false)
                }
                className="px-5 py-2.5 rounded-lg border border-gray-200 text-xs"
              >
                Cancel
              </button>

              <button
                type="submit"
                className="px-5 py-2.5 rounded-lg bg-gray-900 text-white text-xs"
              >
                {editingWarehouse
                  ? "Update"
                  : "Add Warehouse"}
              </button>

            </div>

          </form>

        </div>
      )}

      {/* =====================================================
          WAREHOUSE DETAILS MODAL
          
          PORTAL = PREVENTS MODAL FROM BEING HIDDEN
      ===================================================== */}

      {selectedWarehouse &&
        typeof document !== "undefined" &&
        createPortal(
          <div
            className="fixed inset-0 bg-black/60 flex items-center justify-center z-[99999] p-4"
            onMouseDown={(e) => {
              if (e.target === e.currentTarget) {
                closeWarehouseDetails();
              }
            }}
          >

            <div
              className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
              onMouseDown={(e) =>
                e.stopPropagation()
              }
            >

              {/* HEADER */}

              <div className="flex justify-between items-start">

                <div>

                  <p className="text-[10px] tracking-widest text-gray-400">
                    {selectedWarehouse.code}
                  </p>

                  <h2 className="text-2xl font-serif text-gray-900 mt-1">
                    {selectedWarehouse.name}
                  </h2>

                  <p className="text-xs text-gray-500 mt-1">
                    Warehouse Details
                  </p>

                </div>

                <button
                  type="button"
                  onClick={closeWarehouseDetails}
                  className="w-9 h-9 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-700 text-xl"
                >
                  ×
                </button>

              </div>

              {/* DETAILS */}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-6">

                <div className="bg-[#f7f6f2] rounded-xl p-4">

                  <p className="text-[9px] tracking-widest text-gray-400">
                    LOCATION
                  </p>

                  <p className="text-sm text-gray-900 mt-2">
                    {selectedWarehouse.location}
                  </p>

                </div>

                <div className="bg-[#f7f6f2] rounded-xl p-4">

                  <p className="text-[9px] tracking-widest text-gray-400">
                    MANAGER
                  </p>

                  <p className="text-sm text-gray-900 mt-2">
                    {selectedWarehouse.manager}
                  </p>

                </div>

                <div className="bg-[#f7f6f2] rounded-xl p-4">

                  <p className="text-[9px] tracking-widest text-gray-400">
                    TOTAL CAPACITY
                  </p>

                  <p className="text-sm text-gray-900 mt-2">
                    {selectedWarehouse.capacity.toLocaleString()}
                  </p>

                </div>

                <div className="bg-[#f7f6f2] rounded-xl p-4">

                  <p className="text-[9px] tracking-widest text-gray-400">
                    USED CAPACITY
                  </p>

                  <p className="text-sm text-gray-900 mt-2">
                    {selectedWarehouse.used.toLocaleString()}
                  </p>

                </div>

              </div>

              {/* CAPACITY */}

              {(() => {
                const percentage =
                  selectedWarehouse.capacity > 0
                    ? Math.round(
                        (selectedWarehouse.used /
                          selectedWarehouse.capacity) *
                          100
                      )
                    : 0;

                const warehouseItems =
                  inventory.filter((item) =>
                    item.warehouse.startsWith(
                      selectedWarehouse.code
                    )
                  );

                return (
                  <div className="mt-6">

                    <div className="flex justify-between items-center mb-2">

                      <p className="text-xs text-gray-500">
                        Capacity Utilization
                      </p>

                      <p className="text-xs font-medium text-gray-900">
                        {percentage}%
                      </p>

                    </div>

                    <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">

                      <div
                        className={`h-full ${
                          percentage >= 90
                            ? "bg-red-500"
                            : percentage >= 70
                            ? "bg-yellow-500"
                            : "bg-gray-800"
                        }`}
                        style={{
                          width: `${Math.min(
                            percentage,
                            100
                          )}%`,
                        }}
                      />

                    </div>

                    {/* ITEMS */}

                    <div className="mt-6">

                      <div className="flex justify-between items-center mb-3">

                        <p className="text-xs text-gray-500">
                          Items in this warehouse
                        </p>

                        <span className="text-[10px] bg-gray-100 px-2 py-1 rounded-md text-gray-500">
                          {warehouseItems.length} items
                        </span>

                      </div>

                      {warehouseItems.length === 0 ? (

                        <div className="bg-[#f7f6f2] rounded-xl p-6 text-center">

                          <p className="text-sm font-serif text-gray-900">
                            No inventory items
                          </p>

                          <p className="text-xs text-gray-400 mt-1">
                            This warehouse currently has no stock.
                          </p>

                        </div>

                      ) : (

                        <div className="space-y-2 max-h-64 overflow-y-auto">

                          {warehouseItems.map((item) => (

                            <div
                              key={item.sku}
                              className="flex items-center justify-between bg-[#f7f6f2] rounded-xl px-4 py-3"
                            >

                              <div>

                                <p className="text-xs font-medium text-gray-900">
                                  {item.name}
                                </p>

                                <p className="text-[9px] text-gray-400 mt-1">
                                  {item.sku}
                                </p>

                              </div>

                              <div className="text-right">

                                <p className="text-xs text-gray-900">
                                  {item.quantity}{" "}
                                  {item.unit}
                                </p>

                                <p
                                  className={`text-[9px] mt-1`}
                                >
                                  {item.status}
                                </p>

                              </div>

                            </div>

                          ))}

                        </div>

                      )}

                    </div>

                  </div>
                );
              })()}

              {/* ACTIONS */}

              <div className="flex flex-col sm:flex-row justify-end gap-2 mt-7 pt-5 border-t border-gray-100">

                <button
                  type="button"
                  onClick={() => {
                    const warehouseToEdit =
                      selectedWarehouse;

                    setSelectedWarehouse(null);

                    handleEditWarehouse(
                      warehouseToEdit
                    );
                  }}
                  className="px-5 py-2.5 rounded-lg border border-gray-200 text-xs hover:bg-gray-50"
                >
                  Edit Warehouse
                </button>

                <button
                  type="button"
                  onClick={closeWarehouseDetails}
                  className="px-5 py-2.5 rounded-lg bg-gray-900 text-white text-xs hover:bg-gray-800"
                >
                  Close
                </button>

              </div>

            </div>

          </div>,
          document.body
        )}

      {/* =====================================================
          MOVEMENT MODAL
      ===================================================== */}

      {showMovement && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">

          <form
            onSubmit={handleMovement}
            className="bg-white rounded-2xl w-full max-w-lg p-6 shadow-2xl"
          >

            <div className="flex justify-between items-center mb-5">

              <h2 className="text-xl font-serif">
                Add Stock Movement
              </h2>

              <button
                type="button"
                onClick={() => setShowMovement(false)}
                className="text-gray-400 text-xl"
              >
                ×
              </button>

            </div>

            <div className="space-y-4">

              <select
                required
                value={movementForm.sku}
                onChange={(e) =>
                  setMovementForm({
                    ...movementForm,
                    sku: e.target.value,
                  })
                }
                className="input"
              >

                <option value="">
                  Select item
                </option>

                {inventory.map((item) => (
                  <option
                    key={item.sku}
                    value={item.sku}
                  >
                    {item.sku} - {item.name}
                  </option>
                ))}

              </select>

              <select
                value={movementForm.type}
                onChange={(e) =>
                  setMovementForm({
                    ...movementForm,
                    type: e.target.value,
                  })
                }
                className="input"
              >
                <option value="IN">
                  Stock In
                </option>

                <option value="OUT">
                  Stock Out
                </option>
              </select>

              <input
                required
                type="number"
                min="1"
                placeholder="Quantity"
                value={movementForm.quantity}
                onChange={(e) =>
                  setMovementForm({
                    ...movementForm,
                    quantity: e.target.value,
                  })
                }
                className="input"
              />

              <select
                value={movementForm.warehouse}
                onChange={(e) =>
                  setMovementForm({
                    ...movementForm,
                    warehouse: e.target.value,
                  })
                }
                className="input"
              >

                {warehouses.map((warehouse) => (
                  <option
                    key={warehouse.id}
                    value={`${warehouse.code} – ${warehouse.name}`}
                  >
                    {warehouse.code} –{" "}
                    {warehouse.name}
                  </option>
                ))}

              </select>

              <input
                placeholder="Reference / PO number"
                value={movementForm.reference}
                onChange={(e) =>
                  setMovementForm({
                    ...movementForm,
                    reference: e.target.value,
                  })
                }
                className="input"
              />

            </div>

            <div className="flex justify-end gap-2 mt-6">

              <button
                type="button"
                onClick={() => setShowMovement(false)}
                className="px-5 py-2.5 rounded-lg border border-gray-200 text-xs"
              >
                Cancel
              </button>

              <button
                type="submit"
                className="px-5 py-2.5 rounded-lg bg-gray-900 text-white text-xs"
              >
                Save Movement
              </button>

            </div>

          </form>

        </div>
      )}

      {/* =====================================================
          STOCK TAKE MODAL
      ===================================================== */}

      {showStockTake && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">

          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl">

            <h2 className="text-xl font-serif text-gray-900">
              Start Stock Take
            </h2>

            <p className="text-xs text-gray-500 mt-2">
              Start a physical inventory count for your current stock.
            </p>

            <div className="mt-5 bg-[#f7f6f2] rounded-xl p-4">

              <div className="flex justify-between text-sm mb-2">

                <span className="text-gray-500">
                  Total SKUs
                </span>

                <span className="font-medium">
                  {inventory.length}
                </span>

              </div>

              <div className="flex justify-between text-sm">

                <span className="text-gray-500">
                  Warehouses
                </span>

                <span className="font-medium">
                  {warehouses.length}
                </span>

              </div>

            </div>

            <div className="flex justify-end gap-2 mt-6">

              <button
                type="button"
                onClick={() =>
                  setShowStockTake(false)
                }
                className="px-5 py-2.5 rounded-lg border border-gray-200 text-xs"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleStockTake}
                className="px-5 py-2.5 rounded-lg bg-gray-900 text-white text-xs"
              >
                Start Stock Take
              </button>

            </div>

          </div>

        </div>
      )}

      {/* =====================================================
          INPUT STYLE
      ===================================================== */}

      <style>
        {`
          .input {
            width: 100%;
            background: #f7f6f2;
            border: 1px solid #e5e2dc;
            border-radius: 10px;
            padding: 10px 12px;
            font-size: 12px;
            outline: none;
          }

          .input:focus {
            border-color: #999;
          }

          button {
            -webkit-tap-highlight-color: transparent;
          }
        `}
      </style>

    </div>
  );
};

export default Dashboard;