import React, { useMemo, useState } from "react";
import {
  Search,
  Plus,
  Package,
  Warehouse,
  ArrowDownUp,
  RefreshCw,
  LogOut,
} from "lucide-react";

const stockData = [
  {
    sku: "SKU-1042",
    name: "Steel Plate 10mm",
    category: "Raw Material",
    warehouse: "W1 – Main",
    qty: 840,
    minLevel: 200,
    unit: "kg",
    value: "₹4,20,000",
    status: "In Stock",
  },
  {
    sku: "SKU-1041",
    name: "Zinc Ingot",
    category: "Raw Material",
    warehouse: "W1 – Main",
    qty: 120,
    minLevel: 150,
    unit: "kg",
    value: "₹1,80,000",
    status: "Low Stock",
  },
  {
    sku: "SKU-1040",
    name: "M8 Hex Bolts (Box/200)",
    category: "Hardware",
    warehouse: "W2 – Stores",
    qty: 0,
    minLevel: 50,
    unit: "box",
    value: "₹0",
    status: "Out of Stock",
  },
  {
    sku: "SKU-1039",
    name: "Sigma Brackets A4",
    category: "Components",
    warehouse: "W1 – Main",
    qty: 340,
    minLevel: 100,
    unit: "pcs",
    value: "₹2,04,000",
    status: "In Stock",
  },
  {
    sku: "SKU-1038",
    name: "Hydraulic Oil 15W40",
    category: "Consumable",
    warehouse: "W2 – Stores",
    qty: 28,
    minLevel: 40,
    unit: "litre",
    value: "₹11,200",
    status: "Low Stock",
  },
  {
    sku: "SKU-1037",
    name: "Safety Gloves (pair)",
    category: "PPE",
    warehouse: "W2 – Stores",
    qty: 150,
    minLevel: 60,
    unit: "pair",
    value: "₹18,000",
    status: "In Stock",
  },
];

const tabs = ["Stock", "Warehouses", "Movements", "Replenishment"];

export default function StockPage() {
  const [activeTab, setActiveTab] = useState("Stock");
  const [filter, setFilter] = useState("All");
  const [search, setSearch] = useState("");

  const filteredStock = useMemo(() => {
    return stockData.filter((item) => {
      const matchesSearch =
        item.name.toLowerCase().includes(search.toLowerCase()) ||
        item.sku.toLowerCase().includes(search.toLowerCase());

      const matchesFilter =
        filter === "All" ||
        (filter === "In Stock" && item.status === "In Stock") ||
        (filter === "Low Stock" && item.status === "Low Stock") ||
        (filter === "Out of Stock" && item.status === "Out of Stock");

      return matchesSearch && matchesFilter;
    });
  }, [search, filter]);

  return (
    <div className="min-h-screen bg-[#f5f4ef] text-[#171916] flex">
      {/* SIDEBAR */}
      <aside className="w-[102px] bg-[#111512] min-h-screen text-white flex flex-col items-center">
        {/* Logo */}
        <div className="w-full h-[72px] flex items-center justify-center border-b border-[#292d29]">
          <div className="w-9 h-9 rounded-lg bg-[#d7e3d0] text-[#182019] flex items-center justify-center font-serif text-xl">
            E
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 w-full pt-5 space-y-3">
          <SideItem icon={<Package size={18} />} label="Inventory" active />
          <SideItem icon={<Warehouse size={18} />} label="Warehouse" />
          <SideItem icon={<ArrowDownUp size={18} />} label="Movements" />
          <SideItem icon={<RefreshCw size={18} />} label="Replenish" />
        </nav>

        {/* Logout */}
        <div className="pb-6">
          <button className="text-[#8e958d] hover:text-white transition">
            <LogOut size={18} />
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 px-8 py-7 overflow-auto">
        {/* HEADER */}
        <div className="flex items-start justify-between mb-7">
          <div>
            <p className="text-[10px] tracking-[0.2em] uppercase text-[#9a9d95] mb-1">
              Inventory
            </p>

            <h1 className="font-serif text-[30px] leading-tight">
              Inventory Control
            </h1>
          </div>

          <div className="flex gap-2">
            <button className="h-10 px-5 rounded-xl border border-[#deddd5] bg-[#faf9f5] text-xs hover:bg-white transition">
              Stock Take
            </button>

            <button className="h-10 px-5 rounded-xl bg-[#151815] text-white text-xs flex items-center gap-2 hover:bg-[#252925] transition">
              <Plus size={14} />
              Add Item
            </button>
          </div>
        </div>

        {/* SUMMARY CARDS */}
        <div className="grid grid-cols-4 gap-3 mb-6">
          <SummaryCard
            value="368"
            label="TOTAL SKUS"
            description="Across 3 warehouses"
          />

          <SummaryCard
            value="₹2.44 Cr"
            label="STOCK VALUE"
            description="At cost price"
          />

          <SummaryCard
            value="12"
            label="LOW STOCK ITEMS"
            description="Need reorder"
          />

          <SummaryCard
            value="3"
            label="OUT OF STOCK"
            description="Urgent action needed"
          />
        </div>

        {/* TABS */}
        <div className="flex items-center gap-7 border-b border-transparent mb-5">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`
                text-[10px] uppercase tracking-[0.14em] pb-3
                transition relative
                ${
                  activeTab === tab
                    ? "text-[#222520] font-medium"
                    : "text-[#999c94]"
                }
              `}
            >
              {activeTab === tab && (
                <span className="absolute left-0 right-0 -bottom-[1px] h-[2px] bg-[#222520]" />
              )}

              {tab}
            </button>
          ))}
        </div>

        {/* STOCK TABLE CONTAINER */}
        <section className="bg-[#fbfaf7] border border-[#e2e0d8] rounded-2xl overflow-hidden">
          {/* SEARCH + FILTERS */}
          <div className="px-5 py-4 flex justify-between items-center border-b border-[#e5e3dc]">
            <div className="relative w-[370px]">
              <Search
                size={15}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-[#b0b1ab]"
              />

              <input
                type="text"
                placeholder="Search by name or SKU..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="
                  w-full h-[35px]
                  pl-9 pr-3
                  rounded-xl
                  border border-[#e2e0d8]
                  bg-[#f5f4ef]
                  outline-none
                  text-xs
                  placeholder:text-[#a9aaa4]
                  focus:border-[#b9b9b0]
                "
              />
            </div>

            <div className="flex gap-2">
              {["All", "In Stock", "Low Stock", "Out of Stock"].map(
                (item) => (
                  <button
                    key={item}
                    onClick={() => setFilter(item)}
                    className={`
                      h-7 px-3 rounded-lg border text-[10px]
                      transition
                      ${
                        filter === item
                          ? "bg-[#ecebe5] border-[#d8d6cd] text-[#292b27]"
                          : "bg-[#fbfaf7] border-[#deddd5] text-[#777b73] hover:bg-[#f1f0ea]"
                      }
                    `}
                  >
                    {item}
                  </button>
                )
              )}
            </div>
          </div>

          {/* TABLE */}
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-[#f4f3ee] border-b border-[#e1dfd7]">
                  <TableHeader>SKU</TableHeader>
                  <TableHeader>ITEM NAME</TableHeader>
                  <TableHeader>CATEGORY</TableHeader>
                  <TableHeader>WAREHOUSE</TableHeader>
                  <TableHeader>QTY</TableHeader>
                  <TableHeader>
                    <span className="leading-3 block">
                      MIN
                      <br />
                      LEVEL
                    </span>
                  </TableHeader>
                  <TableHeader>UNIT</TableHeader>
                  <TableHeader>VALUE</TableHeader>
                  <TableHeader>STATUS</TableHeader>
                </tr>
              </thead>

              <tbody>
                {filteredStock.map((item) => (
                  <StockRow key={item.sku} item={item} />
                ))}
              </tbody>
            </table>

            {filteredStock.length === 0 && (
              <div className="py-12 text-center text-sm text-[#999b94]">
                No stock items found.
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}

/* ---------------- COMPONENTS ---------------- */

function SideItem({ icon, label, active }) {
  return (
    <button
      className={`
        w-full h-[62px] flex flex-col items-center justify-center gap-1
        text-[9px] uppercase tracking-wide
        transition
        ${
          active
            ? "bg-[#242b23] text-[#d8e4d2] border-y border-[#354033]"
            : "text-[#777c76] hover:text-white"
        }
      `}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

function SummaryCard({ value, label, description }) {
  return (
    <div className="h-[99px] bg-[#fbfaf7] border border-[#e2e0d8] rounded-2xl px-4 py-4">
      <div className="font-serif text-[25px] leading-none mb-2">
        {value}
      </div>

      <div className="text-[9px] uppercase tracking-[0.13em] text-[#999b93] mb-1">
        {label}
      </div>

      <div className="text-[10px] text-[#777a72]">
        {description}
      </div>
    </div>
  );
}

function TableHeader({ children }) {
  return (
    <th className="text-left px-4 py-3 text-[8px] font-medium tracking-[0.16em] text-[#9b9d96] uppercase">
      {children}
    </th>
  );
}

function StockRow({ item }) {
  const statusStyle = {
    "In Stock": "bg-[#e1ebdf] text-[#3d5940]",
    "Low Stock": "bg-[#ece8dc] text-[#746a4d]",
    "Out of Stock": "bg-[#eadfdd] text-[#76534f]",
  };

  return (
    <tr className="border-b border-[#e5e3dc] last:border-b-0 hover:bg-[#f8f7f2] transition">
      {/* SKU */}
      <td className="px-4 py-4 w-[80px]">
        <span className="text-[9px] text-[#999c95] leading-3">
          {item.sku.slice(0, 4)}-
          <br />
          {item.sku.slice(4)}
        </span>
      </td>

      {/* NAME */}
      <td className="px-4 py-4 min-w-[150px]">
        <div className="font-serif text-[14px] leading-[18px] text-[#161815]">
          {item.name}
        </div>
      </td>

      {/* CATEGORY */}
      <td className="px-4 py-4">
        <span className="inline-block px-2 py-1 rounded-md bg-[#f0efea] border border-[#e1dfd7] text-[9px] text-[#777a73]">
          {item.category}
        </span>
      </td>

      {/* WAREHOUSE */}
      <td className="px-4 py-4">
        <span className="text-[9px] text-[#777b73] leading-3">
          {item.warehouse.split(" – ")[0]}
          <br />
          {item.warehouse.split(" – ")[1]}
        </span>
      </td>

      {/* QTY */}
      <td className="px-4 py-4">
        <span className="font-mono text-[11px] font-medium">
          {item.qty}
        </span>
      </td>

      {/* MIN LEVEL */}
      <td className="px-4 py-4">
        <span className="font-mono text-[10px] text-[#8d9088]">
          {item.minLevel}
        </span>
      </td>

      {/* UNIT */}
      <td className="px-4 py-4">
        <span className="text-[9px] text-[#777a73]">
          {item.unit}
        </span>
      </td>

      {/* VALUE */}
      <td className="px-4 py-4">
        <span className="font-mono text-[11px] font-medium">
          {item.value}
        </span>
      </td>

      {/* STATUS */}
      <td className="px-4 py-4">
        <span
          className={`
            inline-flex items-center
            px-3 py-2
            rounded-lg
            text-[9px]
            uppercase
            leading-3
            font-medium
            ${statusStyle[item.status]}
          `}
        >
          {item.status === "Out of Stock" ? (
            <>
              OUT OF
              <br />
              STOCK
            </>
          ) : item.status === "Low Stock" ? (
            <>
              LOW
              <br />
              STOCK
            </>
          ) : (
            <>
              IN
              <br />
              STOCK
            </>
          )}
        </span>
      </td>
    </tr>
  );
}