export default function Warehouse() {
  const warehouses = [
    {
      code: "W1",
      name: "Main Warehouse",
      location: "Pune MIDC",
      area: "12,000 sqft",
      capacity: 78,
      skus: 234,
      value: "₹82 L",
    },
    {
      code: "W2",
      name: "Stores",
      location: "Pune MIDC",
      area: "4,000 sqft",
      capacity: 45,
      skus: 86,
      value: "₹18 L",
    },
    {
      code: "W3",
      name: "Finished Goods",
      location: "Pune MIDC",
      area: "8,000 sqft",
      capacity: 62,
      skus: 48,
      value: "₹1.4 Cr",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
      {warehouses.map((warehouse) => (
        <div
          key={warehouse.code}
          className="rounded-xl border border-[#e1dfd8] bg-white p-4"
        >
          <div className="flex justify-between">
            <div>
              <p className="text-[8px] text-gray-400">
                {warehouse.code}
              </p>

              <h2 className="font-serif text-xl">
                {warehouse.name}
              </h2>

              <p className="mt-1 text-[9px] text-gray-400">
                {warehouse.location} · {warehouse.area}
              </p>
            </div>

            <span className="h-fit rounded-md bg-[#e4eddf] px-3 py-1 text-[8px] text-[#63745c]">
              ACTIVE
            </span>
          </div>

          <div className="mt-5">
            <div className="flex justify-between text-[9px] text-gray-400">
              <span>Capacity used</span>
              <span>{warehouse.capacity}%</span>
            </div>

            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-gray-100">
              <div
                className="h-full rounded-full bg-[#91aa81]"
                style={{
                  width: `${warehouse.capacity}%`,
                }}
              />
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2">
            <div className="rounded-xl bg-[#f5f4f0] p-3">
              <div className="font-serif text-xl">
                {warehouse.skus}
              </div>

              <div className="mt-1 text-[8px] text-gray-400">
                SKUS
              </div>
            </div>

            <div className="rounded-xl bg-[#f5f4f0] p-3">
              <div className="font-serif text-xl">
                {warehouse.value}
              </div>

              <div className="mt-1 text-[8px] text-gray-400">
                VALUE
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}