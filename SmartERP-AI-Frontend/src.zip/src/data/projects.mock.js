export const projectsMockData = []
