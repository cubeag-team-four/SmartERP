export const manufacturingMockData = []
