export const salesMockData = []
