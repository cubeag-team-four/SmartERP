export const settingsMockData = []
