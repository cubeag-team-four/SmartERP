export const crmMockData = []
