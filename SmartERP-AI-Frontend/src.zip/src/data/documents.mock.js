export const documentsMockData = []
