export const companyManagementMockData = []
