export const purchaseMockData = []
