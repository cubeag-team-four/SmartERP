export const inventoryMockData = []
